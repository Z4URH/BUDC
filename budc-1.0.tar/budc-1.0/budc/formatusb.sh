echo "d
1
d
2
d
3
d
w" | fdisk $1

