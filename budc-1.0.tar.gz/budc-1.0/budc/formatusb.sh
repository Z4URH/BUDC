echo "d
1
d
d
w" | fdisk $1
